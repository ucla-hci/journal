How to test Journey?

Method 1: 
	Use "Linux_Mac_ClickMe.sh"

Method 2:

	At root dir, use "npm install" command to install all JavaScript dependencies.

	At python dir, install Python dependencies manually: 
	(Python 3.x is necessary)
		pip3 install textblob
		pip3 install flask
		pip3 install flask_cors
		pip3 install ibm_watson
		pip3 install empath
	Then, use "python3 app.py" command to run backend server.

	Finally, open index.html in  browser to start testing.